<div class="modal-dialog modal-lg">
	<div class="modal-content">
		
		<div class="modal-body as-header">
			header
		</div>

		<div class="modal-body">
			body
		</div>

		<div class="modal-footer">
			footer
		</div>

	</div>
</div>