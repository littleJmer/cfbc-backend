<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RecipeItem extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'item_recipe';
}
